#include<stdio.h>
typedef char literal[256];
void main(void)
{
	/*----Variaveis temporarias----*/
	int T0;
	int T1;
	int T2;
	int T3;
	int T4;
	/*------------------------------*/
